def main():
    print("f")
